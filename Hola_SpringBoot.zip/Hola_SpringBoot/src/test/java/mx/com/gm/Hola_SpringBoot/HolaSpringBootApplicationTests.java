package mx.com.gm.Hola_SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
